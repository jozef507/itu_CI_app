<html>
	<head>
		<title>Diela</title>
		<link href="<?php echo base_url(); ?>css/bootstrap.min.css" rel="stylesheet">
	</head>
<body>


<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
	<div class="container">
		<div class="collapse navbar-collapse" id="navbarColor01">
			<ul class="navbar-nav mr-auto">
				<li class="nav-item">
					<a class="nav-link" href="<?php echo base_url(); ?>">Domov</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="<?php echo base_url(); ?>shows/index">Diela</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="<?php echo base_url(); ?>pages/about">O nás</a>
				</li>
			</ul>
		</div>
	</div>
</nav>


<div class="container" style="margin-top: 40px;margin-bottom: 40px">


